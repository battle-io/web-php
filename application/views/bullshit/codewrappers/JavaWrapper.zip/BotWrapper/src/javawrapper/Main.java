/*
 // ************************************************************
//
//  Copyright 2010 Department of Applied Mathematics (APPM) at the
//		       University of Colorado at Boulder (UCB)
//
//  Revision History:
//  <12/18/2010	tmj		Version for release to codewars>
//
//  Confidential: Not for use or disclosure outside APPM-UCB without
//                        prior written consent.
//
// ***********************************************************

 */

package javawrapper;

public class Main {

    public static void main(String[] args) {
        
        String[] msg;
        String messageType;
        String metaData;
        
        /* LOGIN_INFORM variables (botName, authenticationKey)
           These variables will be sent to the server to verify your and your
           bot's identity. This information must be correct or your connection
           will be refused.  Data found in online profile.  */
        
        BotConnector myBot = new BotConnector();
        
        myBot.setEmail("");
        myBot.setBotName("");
        myBot.setAuthenticationKey("");

        /* myBot.connect()
           This command packages your login credentials and sends a
           LOGIN_INFORM command to the code-wars game server. */
        myBot.connect();

        Integer myMove = 3;

        while(true){
            /* myBot.getMsg()
               Retrieves incoming commands sent by the server. The command is
               returned as an array: [String commandType, String metaData]
            */
            msg = myBot.getMsg();
            messageType = msg[0];
            metaData = msg[1];
            
            /*
             * Game Messages that require responses
             */
            if(messageType.equals("GAME_INITIALIZE")){
                System.out.println( "New game started" );
            }
            else if(messageType.equals("PLAYCARDS_REQUEST")){

                String cards = "1";
                System.out.println( "Played cards : " + cards );
                myBot.sendReply("PLAYCARDS_REPLY", cards  );
            }    
            else if(messageType.equals("TURN_SUMMARY")){
                System.out.println( "Turn Summary : " + metaData );
                myBot.sendReply("TURN_REPLY", "");
            }
            
            /*
             * Games Messages that don't require a response
             */
            else if(messageType.equals("BULLSHIT_RESULT")){
                System.out.println( "Bullshit result : " + metaData );
            }
            else if(messageType.equals("CARD_MESSAGE")){
                System.out.println( "Recieved cards : " + metaData );
            }
            else if(messageType.equals("GAME_ORDER")){
                System.out.println("Playing against bots : " + metaData);
            }
            else if(messageType.equals("GAME_WINNER")){
                // View Incoming Message:
                System.out.println("The winner of the Game was : " + metaData);
            }
            else if(messageType.equals("DISCONNECT_BOT_REMOTE")){
            }
            /*
             * Server Messages that don't require response
             */
            else if(messageType.equals("SERVER_MESSAGE")){
            }
            else if(messageType.equals("GAME_REPORT")){                
                /* www.code-wars.com has provided you a game report.
                   Please reference www.code-wars.com to obtain the format of
                   this variable for the game you are playing. */                
            }
            else if(messageType.equals("GAME_ABORT")){
                /* www.code-wars.com has provided you a game abort command.
                   Please reference www.code-wars.com to obtain the format of
                   this variable for the game you are playing. */
            }               
        }   
    }
}
